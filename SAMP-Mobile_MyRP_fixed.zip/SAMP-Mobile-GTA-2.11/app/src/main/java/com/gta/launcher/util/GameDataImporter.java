package com.gta.launcher.util;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * Копирует файлы установленной у игрока GTA San Andreas (папки anim, audio, data, models,
 * texdb, text, textures, rockstar) в папку клиента /storage/emulated/0/GTA/.
 * Работает с обычной папкой (File) и с папкой, выбранной через системный выбор (SAF).
 */
public final class GameDataImporter {

    public interface Listener {
        void onProgress(String message);

        void onFinished(boolean success, String message);
    }

    public static final String TARGET_DIR = "/storage/emulated/0/GTA/";

    private static final String TAG = "GameDataImporter";
    private static final String[] GAME_FOLDERS = {
            "anim", "audio", "data", "models", "texdb", "text", "textures", "rockstar"
    };
    private static final Set<String> FOLDER_SET = new HashSet<>(Arrays.asList(GAME_FOLDERS));
    // Если рядом лежит хотя бы столько папок игры, считаем это корнем с данными
    private static final int MIN_FOLDERS = 3;
    private static final int MAX_DEPTH = 4;

    private static final String[] AUTO_PATHS = {
            "/storage/emulated/0/Android/data/com.rockstargames.gtasa/files",
            "/storage/emulated/0/Android/data/com.rockstargames.gtasa"
    };

    private interface Work {
        void run() throws Exception;
    }

    private static final class Child {
        String docId;
        String name;
        boolean dir;
        long size;
    }

    private final Context context;
    private final Listener listener;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private int copiedFiles = 0;
    private long bytesCopied = 0;
    private long lastReportedBytes = 0;
    // файлы, записанные в этом запуске: патч-OBB должен перезаписывать файлы из main-OBB
    private final Set<String> writtenThisRun = new HashSet<>();

    public GameDataImporter(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    // ---------------------------------------------------------------- проверки

    /** Есть ли в папке клиента файлы игры. */
    public static boolean isInstalled() {
        int found = 0;
        for (String name : GAME_FOLDERS) {
            String[] content = new File(TARGET_DIR + name).list();
            if (content != null && content.length > 0) found++;
        }
        return found >= MIN_FOLDERS;
    }

    /** Пытается найти игру обычным путём (работает не на всех версиях Android). */
    public static File findAutoSource() {
        for (String path : AUTO_PATHS) {
            File dir = new File(path);
            if (dir.isDirectory() && findGameRoot(dir, 0) != null) return dir;
        }
        return null;
    }

    // ---------------------------------------------------------------- запуск

    public void importFromFolder(final File root) {
        start(() -> {
            File gameRoot = findGameRoot(root, 0);
            if (gameRoot == null) {
                List<File> obbs = new ArrayList<>();
                collectFileObbs(root, 0, obbs);
                if (obbs.isEmpty()) throw new NotFoundException();
                sortObbs(obbs);
                for (File obb : obbs) extractObbFile(obb);
                return;
            }
            File[] children = gameRoot.listFiles();
            if (children == null) throw new NotFoundException();
            for (File child : children) {
                if (child.isDirectory() && FOLDER_SET.contains(child.getName().toLowerCase(Locale.ROOT))) {
                    copyFileTree(child, new File(TARGET_DIR + child.getName().toLowerCase(Locale.ROOT)));
                }
            }
        });
    }

    public void importFromTree(final Uri tree) {
        start(() -> {
            String rootId = DocumentsContract.getTreeDocumentId(tree);
            Child gameRoot = findTreeRoot(tree, rootId, 0);
            if (gameRoot == null) {
                List<Child> obbs = new ArrayList<>();
                collectTreeObbs(tree, rootId, 0, obbs);
                if (obbs.isEmpty()) throw new NotFoundException();
                Collections.sort(obbs, (a, b) -> a.name.compareToIgnoreCase(b.name));
                for (Child obb : obbs) {
                    Uri docUri = DocumentsContract.buildDocumentUriUsingTree(tree, obb.docId);
                    InputStream in = context.getContentResolver().openInputStream(docUri);
                    if (in == null) throw new IOException("Не удалось открыть " + obb.name);
                    extractObbStream(in, obb.name);
                }
                return;
            }
            for (Child child : listChildren(tree, gameRoot.docId)) {
                if (child.dir && child.name != null
                        && FOLDER_SET.contains(child.name.toLowerCase(Locale.ROOT))) {
                    copyTreeDir(tree, child.docId, new File(TARGET_DIR + child.name.toLowerCase(Locale.ROOT)));
                }
            }
        });
    }

    /** Распаковывает найденные .obb (сначала main, потом patch) прямо в папку клиента. */
    public void importFromObbs(final List<File> obbs) {
        start(() -> {
            List<File> sorted = new ArrayList<>(obbs);
            sortObbs(sorted);
            for (File obb : sorted) extractObbFile(obb);
        });
    }

    /** Ищет .obb GTA San Andreas в обычных папках (нужен доступ ко всем файлам). */
    public static List<File> findAutoObbs() {
        String[] dirs = {
                TARGET_DIR,
                "/storage/emulated/0/Download/",
                "/storage/emulated/0/",
                "/storage/emulated/0/Android/obb/com.rockstargames.gtasa/"
        };
        List<File> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (String dir : dirs) {
            File[] list = new File(dir).listFiles();
            if (list == null) continue;
            boolean anyName = dir.equals(TARGET_DIR);
            for (File f : list) {
                String name = f.getName().toLowerCase(Locale.ROOT);
                if (f.isFile() && name.endsWith(".obb") && (anyName || name.contains("gtasa"))
                        && seen.add(name)) {
                    result.add(f);
                }
            }
        }
        sortObbs(result);
        return result;
    }

    private static final class NotFoundException extends Exception {
    }

    private void start(final Work work) {
        copiedFiles = 0;
        bytesCopied = 0;
        lastReportedBytes = 0;
        writtenThisRun.clear();
        new Thread(() -> {
            try {
                post("Копирование файлов игры…");
                work.run();
                final boolean ok = isInstalled();
                final String msg = ok
                        ? "Готово. Скопировано файлов: " + copiedFiles
                        : "Скопировано файлов: " + copiedFiles + ", но нужных папок игры не хватает";
                finish(ok, msg);
            } catch (NotFoundException e) {
                finish(false, "В выбранной папке нет файлов игры (anim, audio, data, models, texdb…) и нет файла .obb");
            } catch (Exception e) {
                Log.e(TAG, "Import failed: " + e.getMessage(), e);
                finish(false, "Ошибка копирования: " + e.getMessage());
            }
        }).start();
    }

    private void post(final String text) {
        ui.post(() -> listener.onProgress(text));
    }

    private void finish(final boolean ok, final String text) {
        ui.post(() -> listener.onFinished(ok, text));
    }

    // ---------------------------------------------------------------- обычные папки

    private static File findGameRoot(File dir, int depth) {
        File[] list = dir.listFiles();
        if (list == null) return null;
        int hits = 0;
        for (File f : list) {
            if (f.isDirectory() && FOLDER_SET.contains(f.getName().toLowerCase(Locale.ROOT))) hits++;
        }
        if (hits >= MIN_FOLDERS) return dir;
        if (depth >= MAX_DEPTH) return null;
        for (File f : list) {
            if (f.isDirectory()) {
                File found = findGameRoot(f, depth + 1);
                if (found != null) return found;
            }
        }
        return null;
    }

    private void copyFileTree(File src, File dst) throws IOException {
        if (src.isDirectory()) {
            if (!dst.exists() && !dst.mkdirs()) throw new IOException("Не удалось создать " + dst);
            File[] list = src.listFiles();
            if (list == null) return;
            for (File f : list) {
                copyFileTree(f, new File(dst, f.getName()));
            }
        } else {
            if (shouldSkip(dst, src.length())) return;
            writeStream(new FileInputStream(src), dst);
        }
    }

    // ---------------------------------------------------------------- папка из системного выбора (SAF)

    private Child findTreeRoot(Uri tree, String docId, int depth) {
        List<Child> children = listChildren(tree, docId);
        int hits = 0;
        for (Child c : children) {
            if (c.dir && c.name != null && FOLDER_SET.contains(c.name.toLowerCase(Locale.ROOT))) hits++;
        }
        if (hits >= MIN_FOLDERS) {
            Child root = new Child();
            root.docId = docId;
            root.dir = true;
            return root;
        }
        if (depth >= MAX_DEPTH) return null;
        for (Child c : children) {
            if (c.dir) {
                Child found = findTreeRoot(tree, c.docId, depth + 1);
                if (found != null) return found;
            }
        }
        return null;
    }

    private List<Child> listChildren(Uri tree, String docId) {
        List<Child> result = new ArrayList<>();
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        String[] projection = {
                Document.COLUMN_DOCUMENT_ID,
                Document.COLUMN_DISPLAY_NAME,
                Document.COLUMN_MIME_TYPE,
                Document.COLUMN_SIZE
        };
        try (Cursor cursor = context.getContentResolver().query(childrenUri, projection, null, null, null)) {
            if (cursor == null) return result;
            while (cursor.moveToNext()) {
                Child child = new Child();
                child.docId = cursor.getString(0);
                child.name = cursor.getString(1);
                child.dir = Document.MIME_TYPE_DIR.equals(cursor.getString(2));
                child.size = cursor.isNull(3) ? -1 : cursor.getLong(3);
                result.add(child);
            }
        } catch (Exception e) {
            Log.e(TAG, "listChildren failed: " + e.getMessage(), e);
        }
        return result;
    }

    private void copyTreeDir(Uri tree, String docId, File dst) throws IOException {
        if (!dst.exists() && !dst.mkdirs()) throw new IOException("Не удалось создать " + dst);
        for (Child child : listChildren(tree, docId)) {
            // защита от некорректных имён из чужого провайдера файлов
            if (child.name == null || child.name.contains("/") || child.name.equals("..")) continue;
            File out = new File(dst, child.name);
            if (child.dir) {
                copyTreeDir(tree, child.docId, out);
            } else {
                if (shouldSkip(out, child.size)) continue;
                Uri docUri = DocumentsContract.buildDocumentUriUsingTree(tree, child.docId);
                InputStream in = context.getContentResolver().openInputStream(docUri);
                if (in == null) throw new IOException("Не удалось открыть " + child.name);
                writeStream(in, out);
            }
        }
    }

    // ---------------------------------------------------------------- общее

    /** Уже скопированный файл того же размера пропускаем, чтобы повторный запуск был быстрым. */
    private static boolean shouldSkip(File dst, long size) {
        return size > 0 && dst.exists() && dst.length() == size;
    }

    private void writeStream(InputStream input, File dst) throws IOException {
        File parent = dst.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            input.close();
            throw new IOException("Не удалось создать " + parent);
        }
        try (InputStream in = input; OutputStream out = new FileOutputStream(dst)) {
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = in.read(buffer)) > 0) {
                out.write(buffer, 0, read);
                bytesCopied += read;
                if (bytesCopied - lastReportedBytes >= 32L * 1024 * 1024) {
                    lastReportedBytes = bytesCopied;
                    post("Скопировано файлов: " + copiedFiles + ", " + (bytesCopied / 1048576) + " МБ");
                }
            }
        }
        copiedFiles++;
        if (copiedFiles % 20 == 0) post("Скопировано файлов: " + copiedFiles);
    }

    // ---------------------------------------------------------------- OBB

    private static void sortObbs(List<File> list) {
        // main идёт раньше patch, patch перезаписывает файлы из main
        Collections.sort(list, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
    }

    private static void collectFileObbs(File dir, int depth, List<File> out) {
        File[] list = dir.listFiles();
        if (list == null) return;
        for (File f : list) {
            if (f.isFile() && f.getName().toLowerCase(Locale.ROOT).endsWith(".obb")) {
                out.add(f);
            } else if (f.isDirectory() && depth < 2) {
                collectFileObbs(f, depth + 1, out);
            }
        }
    }

    private void collectTreeObbs(Uri tree, String docId, int depth, List<Child> out) {
        for (Child c : listChildren(tree, docId)) {
            if (c.name == null) continue;
            if (!c.dir && c.name.toLowerCase(Locale.ROOT).endsWith(".obb")) {
                out.add(c);
            } else if (c.dir && depth < 2) {
                collectTreeObbs(tree, c.docId, depth + 1, out);
            }
        }
    }

    /**
     * Куда в GTA/ записать запись из OBB. Путь обрезается до первой папки игры
     * (anim, audio, data…), остальное не нужно. Возвращает null для чужих записей.
     */
    private static File obbTarget(String entryName) {
        String[] parts = entryName.replace('\\', '/').split("/");
        for (String part : parts) {
            if (part.equals("..")) return null;
        }
        for (int i = 0; i < parts.length - 1; i++) {
            if (FOLDER_SET.contains(parts[i].toLowerCase(Locale.ROOT))) {
                StringBuilder sb = new StringBuilder(TARGET_DIR);
                sb.append(parts[i].toLowerCase(Locale.ROOT));
                for (int j = i + 1; j < parts.length; j++) {
                    if (!parts[j].isEmpty()) sb.append('/').append(parts[j]);
                }
                return new File(sb.toString());
            }
        }
        return null;
    }

    /** OBB лежит в обычной папке: открываем как ZIP с произвольным доступом. */
    private void extractObbFile(File obb) throws IOException {
        post("Распаковка " + obb.getName() + "…");
        ZipFile zip;
        try {
            zip = new ZipFile(obb);
        } catch (IOException e) {
            throw new IOException(obb.getName() + ": не удалось открыть как архив (" + e.getMessage() + ")");
        }
        try (ZipFile zf = zip) {
            long need = 0;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory() || e.getSize() <= 0) continue;
                File out = obbTarget(e.getName());
                if (out != null && !(out.exists() && out.length() == e.getSize())) need += e.getSize();
            }
            long free = new File("/storage/emulated/0").getUsableSpace();
            if (need > free) {
                throw new IOException("Не хватает места: нужно освободить ещё около "
                        + ((need - free) / 1048576 + 1) + " МБ");
            }
            en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                File out = obbTarget(e.getName());
                if (out == null) continue;
                writeObbEntry(zf.getInputStream(e), out, e.getSize());
            }
        }
    }

    /** OBB выбран через системный выбор: читаем как поток. */
    private void extractObbStream(InputStream raw, String name) throws IOException {
        post("Распаковка " + name + "…");
        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(raw, 256 * 1024))) {
            // writeStream закрывает поток, а закрывать надо только весь архив целиком
            InputStream entryStream = new FilterInputStream(zis) {
                @Override
                public void close() {
                }
            };
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                File out = obbTarget(e.getName());
                if (out == null) continue;
                writeObbEntry(entryStream, out, e.getSize());
            }
        }
    }

    private void writeObbEntry(InputStream in, File out, long size) throws IOException {
        String key = out.getPath();
        if (size > 0 && out.exists() && out.length() == size && !writtenThisRun.contains(key)) {
            in.close();
            return;
        }
        writtenThisRun.add(key);
        writeStream(in, out);
    }
}
