package com.gta.launcher.util;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Копирует файлы установленной у игрока GTA San Andreas (папки anim, audio, data, models,
 * texdb, text, textures, rockstar) в папку клиента /storage/emulated/0/GTA/.
 * Работает с обычной папкой (File) и с папкой, выбранной через системный выбор (SAF).
 */
public final class GameDataImporter {

    public interface Listener {
        void onProgress(String message);

        void onFinished(boolean success, String message);
    }

    public static final String TARGET_DIR = "/storage/emulated/0/GTA/";

    private static final String TAG = "GameDataImporter";
    private static final String[] GAME_FOLDERS = {
            "anim", "audio", "data", "models", "texdb", "text", "textures", "rockstar"
    };
    private static final Set<String> FOLDER_SET = new HashSet<>(Arrays.asList(GAME_FOLDERS));
    // Если рядом лежит хотя бы столько папок игры, считаем это корнем с данными
    private static final int MIN_FOLDERS = 3;
    private static final int MAX_DEPTH = 4;

    private static final String[] AUTO_PATHS = {
            "/storage/emulated/0/Android/data/com.rockstargames.gtasa/files",
            "/storage/emulated/0/Android/data/com.rockstargames.gtasa"
    };

    private interface Work {
        void run() throws Exception;
    }

    private static final class Child {
        String docId;
        String name;
        boolean dir;
        long size;
    }

    private final Context context;
    private final Listener listener;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private int copiedFiles = 0;

    public GameDataImporter(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    // ---------------------------------------------------------------- проверки

    /** Есть ли в папке клиента файлы игры. */
    public static boolean isInstalled() {
        int found = 0;
        for (String name : GAME_FOLDERS) {
            String[] content = new File(TARGET_DIR + name).list();
            if (content != null && content.length > 0) found++;
        }
        return found >= MIN_FOLDERS;
    }

    /** Пытается найти игру обычным путём (работает не на всех версиях Android). */
    public static File findAutoSource() {
        for (String path : AUTO_PATHS) {
            File dir = new File(path);
            if (dir.isDirectory() && findGameRoot(dir, 0) != null) return dir;
        }
        return null;
    }

    // ---------------------------------------------------------------- запуск

    public void importFromFolder(final File root) {
        start(() -> {
            File gameRoot = findGameRoot(root, 0);
            if (gameRoot == null) throw new NotFoundException();
            File[] children = gameRoot.listFiles();
            if (children == null) throw new NotFoundException();
            for (File child : children) {
                if (child.isDirectory() && FOLDER_SET.contains(child.getName().toLowerCase(Locale.ROOT))) {
                    copyFileTree(child, new File(TARGET_DIR + child.getName().toLowerCase(Locale.ROOT)));
                }
            }
        });
    }

    public void importFromTree(final Uri tree) {
        start(() -> {
            String rootId = DocumentsContract.getTreeDocumentId(tree);
            Child gameRoot = findTreeRoot(tree, rootId, 0);
            if (gameRoot == null) throw new NotFoundException();
            for (Child child : listChildren(tree, gameRoot.docId)) {
                if (child.dir && child.name != null
                        && FOLDER_SET.contains(child.name.toLowerCase(Locale.ROOT))) {
                    copyTreeDir(tree, child.docId, new File(TARGET_DIR + child.name.toLowerCase(Locale.ROOT)));
                }
            }
        });
    }

    private static final class NotFoundException extends Exception {
    }

    private void start(final Work work) {
        copiedFiles = 0;
        new Thread(() -> {
            try {
                post("Копирование файлов игры…");
                work.run();
                final boolean ok = isInstalled();
                final String msg = ok
                        ? "Готово. Скопировано файлов: " + copiedFiles
                        : "Скопировано файлов: " + copiedFiles + ", но нужных папок игры не хватает";
                finish(ok, msg);
            } catch (NotFoundException e) {
                finish(false, "В выбранной папке нет файлов игры (anim, audio, data, models, texdb…)");
            } catch (Exception e) {
                Log.e(TAG, "Import failed: " + e.getMessage(), e);
                finish(false, "Ошибка копирования: " + e.getMessage());
            }
        }).start();
    }

    private void post(final String text) {
        ui.post(() -> listener.onProgress(text));
    }

    private void finish(final boolean ok, final String text) {
        ui.post(() -> listener.onFinished(ok, text));
    }

    // ---------------------------------------------------------------- обычные папки

    private static File findGameRoot(File dir, int depth) {
        File[] list = dir.listFiles();
        if (list == null) return null;
        int hits = 0;
        for (File f : list) {
            if (f.isDirectory() && FOLDER_SET.contains(f.getName().toLowerCase(Locale.ROOT))) hits++;
        }
        if (hits >= MIN_FOLDERS) return dir;
        if (depth >= MAX_DEPTH) return null;
        for (File f : list) {
            if (f.isDirectory()) {
                File found = findGameRoot(f, depth + 1);
                if (found != null) return found;
            }
        }
        return null;
    }

    private void copyFileTree(File src, File dst) throws IOException {
        if (src.isDirectory()) {
            if (!dst.exists() && !dst.mkdirs()) throw new IOException("Не удалось создать " + dst);
            File[] list = src.listFiles();
            if (list == null) return;
            for (File f : list) {
                copyFileTree(f, new File(dst, f.getName()));
            }
        } else {
            if (shouldSkip(dst, src.length())) return;
            writeStream(new FileInputStream(src), dst);
        }
    }

    // ---------------------------------------------------------------- папка из системного выбора (SAF)

    private Child findTreeRoot(Uri tree, String docId, int depth) {
        List<Child> children = listChildren(tree, docId);
        int hits = 0;
        for (Child c : children) {
            if (c.dir && c.name != null && FOLDER_SET.contains(c.name.toLowerCase(Locale.ROOT))) hits++;
        }
        if (hits >= MIN_FOLDERS) {
            Child root = new Child();
            root.docId = docId;
            root.dir = true;
            return root;
        }
        if (depth >= MAX_DEPTH) return null;
        for (Child c : children) {
            if (c.dir) {
                Child found = findTreeRoot(tree, c.docId, depth + 1);
                if (found != null) return found;
            }
        }
        return null;
    }

    private List<Child> listChildren(Uri tree, String docId) {
        List<Child> result = new ArrayList<>();
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        String[] projection = {
                Document.COLUMN_DOCUMENT_ID,
                Document.COLUMN_DISPLAY_NAME,
                Document.COLUMN_MIME_TYPE,
                Document.COLUMN_SIZE
        };
        try (Cursor cursor = context.getContentResolver().query(childrenUri, projection, null, null, null)) {
            if (cursor == null) return result;
            while (cursor.moveToNext()) {
                Child child = new Child();
                child.docId = cursor.getString(0);
                child.name = cursor.getString(1);
                child.dir = Document.MIME_TYPE_DIR.equals(cursor.getString(2));
                child.size = cursor.isNull(3) ? -1 : cursor.getLong(3);
                result.add(child);
            }
        } catch (Exception e) {
            Log.e(TAG, "listChildren failed: " + e.getMessage(), e);
        }
        return result;
    }

    private void copyTreeDir(Uri tree, String docId, File dst) throws IOException {
        if (!dst.exists() && !dst.mkdirs()) throw new IOException("Не удалось создать " + dst);
        for (Child child : listChildren(tree, docId)) {
            // защита от некорректных имён из чужого провайдера файлов
            if (child.name == null || child.name.contains("/") || child.name.equals("..")) continue;
            File out = new File(dst, child.name);
            if (child.dir) {
                copyTreeDir(tree, child.docId, out);
            } else {
                if (shouldSkip(out, child.size)) continue;
                Uri docUri = DocumentsContract.buildDocumentUriUsingTree(tree, child.docId);
                InputStream in = context.getContentResolver().openInputStream(docUri);
                if (in == null) throw new IOException("Не удалось открыть " + child.name);
                writeStream(in, out);
            }
        }
    }

    // ---------------------------------------------------------------- общее

    /** Уже скопированный файл того же размера пропускаем, чтобы повторный запуск был быстрым. */
    private static boolean shouldSkip(File dst, long size) {
        return size > 0 && dst.exists() && dst.length() == size;
    }

    private void writeStream(InputStream input, File dst) throws IOException {
        File parent = dst.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            input.close();
            throw new IOException("Не удалось создать " + parent);
        }
        try (InputStream in = input; OutputStream out = new FileOutputStream(dst)) {
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = in.read(buffer)) > 0) {
                out.write(buffer, 0, read);
            }
        }
        copiedFiles++;
        if (copiedFiles % 20 == 0) post("Скопировано файлов: " + copiedFiles);
    }
}
