package com.gta.launcher.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.gta.game.R;
import com.gta.game.SAMP;
import com.gta.launcher.util.GameDataImporter;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private Handler handler = new Handler(Looper.getMainLooper());
    private Button startButton;
    private EditText nickInput;
    private TextView serverName, serverAddress, errorText;
    private Button importButton;
    private TextView dataStatus, importProgress;
    private GameDataImporter importer;
    private boolean storagePermissionGranted = false;
    private boolean pendingLaunch = false;
    private boolean pendingImport = false;

    private static final String SETTINGS_PATH = "/storage/emulated/0/GTA/SAMP/settings.ini";
    private static final String PREFS = "launcher";
    private static final String PREF_NICK = "nick";
    // Формат ника, который принимает сервер: Имя_Фамилия, с заглавных букв, до 19 символов
    private static final Pattern NICK_PATTERN = Pattern.compile("^[A-Z][a-z]{1,}_[A-Z][a-z]{1,}$");

    private final ActivityResultLauncher<String[]> requestStoragePermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
                boolean allGranted = true;
                for (Boolean granted : permissions.values()) {
                    if (!granted) {
                        allGranted = false;
                        break;
                    }
                }

                if (allGranted) {
                    storagePermissionGranted = true;
                    Log.d("MainActivity", "All storage permissions granted");
                    onStoragePermissionGranted();
                } else {
                    storagePermissionGranted = false;
                    Log.e("MainActivity", "Storage permissions denied");
                    Toast.makeText(this, "Для работы игры необходим доступ к хранилищу", Toast.LENGTH_LONG).show();

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        requestManageStoragePermission();
                    }
                }
            });

    private final ActivityResultLauncher<Intent> manageStorageLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    if (Environment.isExternalStorageManager()) {
                        storagePermissionGranted = true;
                        Log.d("MainActivity", "Manage storage permission granted");
                        onStoragePermissionGranted();
                    } else {
                        storagePermissionGranted = false;
                        Log.e("MainActivity", "Manage storage permission denied");
                        Toast.makeText(this, "Приложение требует полный доступ к хранилищу", Toast.LENGTH_LONG).show();
                    }
                }
            });

    private final ActivityResultLauncher<Uri> pickGameFolderLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(), uri -> {
                if (uri != null) {
                    setImportBusy(true);
                    importer.importFromTree(uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d("MainActivity", "onCreate started");

        try {
            setFullScreenMode();
            setContentView(R.layout.main_activity);

            Log.d("MainActivity", "ContentView set");

            initViews();
            setupClickListeners();

            checkAndRequestStoragePermission();

            Log.d("MainActivity", "onCreate completed successfully");

        } catch (Exception e) {
            Log.e("MainActivity", "Critical error in onCreate: " + e.getMessage(), e);
            finish();
        }
    }

    private void checkAndRequestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                storagePermissionGranted = true;
                Log.d("MainActivity", "Already have manage storage permission");
            } else {
                requestManageStoragePermission();
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] permissions;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissions = new String[]{
                        android.Manifest.permission.READ_MEDIA_IMAGES,
                        android.Manifest.permission.READ_MEDIA_VIDEO,
                        android.Manifest.permission.READ_MEDIA_AUDIO
                };
            } else {
                permissions = new String[]{
                        android.Manifest.permission.READ_EXTERNAL_STORAGE,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                };
            }

            boolean allGranted = true;
            for (String perm : permissions) {
                if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                storagePermissionGranted = true;
                Log.d("MainActivity", "Already have storage permissions");
            } else {
                requestStoragePermissionLauncher.launch(permissions);
            }
        } else {
            storagePermissionGranted = true;
        }
    }

    private void requestManageStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                manageStorageLauncher.launch(intent);
            } catch (Exception e) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                manageStorageLauncher.launch(intent);
            }
        }
    }

    /** Проверяет ник, записывает настройки подключения и запускает игру. */
    private void launchGame() {
        pendingLaunch = false;
        String nick = nickInput.getText().toString().trim();
        if (!NICK_PATTERN.matcher(nick).matches() || nick.length() > 19) {
            showError(getString(R.string.nick_error));
            return;
        }
        if (!GameDataImporter.isInstalled()) {
            showError(getString(R.string.data_required));
            return;
        }
        String missing = findMissingSampFiles();
        if (missing != null) {
            showError("Не хватает файлов клиента в /storage/emulated/0/GTA/SAMP/: " + missing);
            return;
        }
        hideError();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_NICK, nick).apply();
        try {
            writeConnectionSettings(nick);
        } catch (Exception e) {
            Log.e("MainActivity", "Cannot write settings.ini: " + e.getMessage(), e);
            showError(getString(R.string.settings_write_error));
            return;
        }
        startGame();
    }

    /** Файлы клиента SA-MP, без которых нативная часть падает при старте. Возвращает список недостающих или null. */
    private static String findMissingSampFiles() {
        String[] required = {
                "main.scm", "script.img", "peds.ide", "vehicles.ide",
                "gta.dat", "handling.cfg", "weapon.dat", "fonts/arial_bold.ttf"
        };
        StringBuilder sb = new StringBuilder();
        for (String name : required) {
            if (!new File("/storage/emulated/0/GTA/SAMP/" + name).exists()) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(name);
            }
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    private void showError(String text) {
        errorText.setText(text);
        errorText.setVisibility(View.VISIBLE);
    }

    private void hideError() {
        errorText.setVisibility(View.GONE);
    }

    /** Записывает ник и адрес сервера в settings.ini, который читает клиент при старте. */
    private void writeConnectionSettings(String nick) throws IOException {
        File file = new File(SETTINGS_PATH);
        File dir = file.getParentFile();
        if (dir != null && !dir.exists() && !dir.mkdirs()) {
            throw new IOException("Cannot create " + dir);
        }
        List<String> lines = new ArrayList<>();
        if (file.exists()) {
            lines.addAll(Files.readAllLines(file.toPath(), StandardCharsets.UTF_8));
        }
        String host = getString(R.string.server_host);
        int port = getResources().getInteger(R.integer.server_port);
        setIniValue(lines, "client", "name", nick);
        setIniValue(lines, "client", "host", host);
        setIniValue(lines, "client", "port", String.valueOf(port));
        Files.write(file.toPath(), lines, StandardCharsets.UTF_8);
    }

    /** Меняет (или добавляет) ключ в секции ini-файла, не трогая остальное. */
    private static void setIniValue(List<String> lines, String section, String key, String value) {
        String header = "[" + section + "]";
        int sectionStart = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).trim().equalsIgnoreCase(header)) {
                sectionStart = i;
                break;
            }
        }
        if (sectionStart == -1) {
            if (!lines.isEmpty() && !lines.get(lines.size() - 1).trim().isEmpty()) lines.add("");
            lines.add(header);
            lines.add(key + "=" + value);
            return;
        }
        int sectionEnd = lines.size();
        for (int i = sectionStart + 1; i < lines.size(); i++) {
            String t = lines.get(i).trim();
            if (t.startsWith("[") && t.endsWith("]")) {
                sectionEnd = i;
                break;
            }
        }
        for (int i = sectionStart + 1; i < sectionEnd; i++) {
            String t = lines.get(i).trim();
            int eq = t.indexOf('=');
            if (eq > 0 && t.substring(0, eq).trim().equalsIgnoreCase(key)) {
                lines.set(i, key + "=" + value);
                return;
            }
        }
        lines.add(sectionEnd, key + "=" + value);
    }

    private void setFullScreenMode() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );

            getWindow().setFlags(
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            );

            getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
            getWindow().setNavigationBarColor(android.graphics.Color.TRANSPARENT);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                WindowManager.LayoutParams params = getWindow().getAttributes();
                params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                getWindow().setAttributes(params);
            }

            if (getSupportActionBar() != null) {
                getSupportActionBar().hide();
            }
        } catch (Exception e) {
            Log.e("MainActivity", "Error in setFullScreenMode: " + e.getMessage());
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            try {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                );
            } catch (Exception e) {
                Log.e("MainActivity", "Error in onWindowFocusChanged: " + e.getMessage());
            }
        }
    }

    private void initViews() {
        try {
            startButton = findViewById(R.id.startButton);
            nickInput = findViewById(R.id.nickInput);
            serverName = findViewById(R.id.serverName);
            serverAddress = findViewById(R.id.serverAddress);
            errorText = findViewById(R.id.errorText);

            serverName.setText(getString(R.string.server_name));
            serverAddress.setText(getString(R.string.server_host) + ":" + getResources().getInteger(R.integer.server_port));

            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            nickInput.setText(prefs.getString(PREF_NICK, ""));

            importButton = findViewById(R.id.importButton);
            dataStatus = findViewById(R.id.dataStatus);
            importProgress = findViewById(R.id.importProgress);
            importer = new GameDataImporter(this, new GameDataImporter.Listener() {
                @Override
                public void onProgress(String message) {
                    importProgress.setText(message);
                    importProgress.setVisibility(View.VISIBLE);
                }

                @Override
                public void onFinished(boolean success, String message) {
                    setImportBusy(false);
                    importProgress.setText(message);
                    importProgress.setVisibility(View.VISIBLE);
                    refreshDataStatus();
                }
            });
            refreshDataStatus();
        } catch (Exception e) {
            Log.e("MainActivity", "Error in initViews: " + e.getMessage());
        }
    }

    private void onStoragePermissionGranted() {
        if (pendingImport) {
            pendingImport = false;
            startImportFlow();
        }
        if (pendingLaunch) launchGame();
    }

    /** Показывает, можно ли запускать игру: нужны и файлы GTA, и файлы клиента SA-MP. */
    private void refreshDataStatus() {
        boolean gameOk = GameDataImporter.isInstalled();
        String missing = gameOk ? findMissingSampFiles() : null;
        boolean ready = gameOk && missing == null;

        if (!gameOk) {
            dataStatus.setText("✗ Файлы GTA San Andreas не найдены. Нажмите «Указать папку с игрой»");
            dataStatus.setTextColor(ContextCompat.getColor(this, R.color.br_red_light));
        } else if (missing != null) {
            dataStatus.setText("⚠ Файлы GTA есть, но нет файлов клиента в GTA/SAMP/: " + missing
                    + ". Запускать игру нельзя, она вылетит");
            dataStatus.setTextColor(ContextCompat.getColor(this, R.color.br_red_light));
        } else {
            dataStatus.setText("✓ Всё готово, можно запускать игру");
            dataStatus.setTextColor(ContextCompat.getColor(this, R.color.br_online));
        }
        if (startButton != null) startButton.setAlpha(ready ? 1f : 0.5f);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Игрок мог положить файлы через менеджер файлов и вернуться в лаунчер
        if (dataStatus != null) refreshDataStatus();
    }

    private void setImportBusy(boolean busy) {
        importButton.setEnabled(!busy);
        importButton.setAlpha(busy ? 0.5f : 1f);
    }

    /** Сначала пробуем найти игру сами, если не вышло, даём выбрать папку. */
    private void startImportFlow() {
        File auto = GameDataImporter.findAutoSource();
        if (auto != null) {
            setImportBusy(true);
            importer.importFromFolder(auto);
            return;
        }
        Toast.makeText(this, R.string.pick_folder_toast, Toast.LENGTH_LONG).show();
        try {
            Uri initial = DocumentsContract.buildDocumentUri(
                    "com.android.externalstorage.documents", "primary:Android/data");
            pickGameFolderLauncher.launch(initial);
        } catch (Exception e) {
            Log.e("MainActivity", "Cannot open folder picker with hint: " + e.getMessage());
            pickGameFolderLauncher.launch(null);
        }
    }

    private void startGame() {
        try {
            Log.d("MainActivity", "Starting game");
            Intent gameIntent = new Intent(MainActivity.this, SAMP.class);
            startActivity(gameIntent);
        } catch (Exception e) {
            Log.e("MainActivity", "Error starting game: " + e.getMessage());
        }
    }

    private void setupClickListeners() {
        try {
            startButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100)
                                .withEndAction(new Runnable() {
                                    @Override
                                    public void run() {
                                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                                    }
                                })
                                .start();

                        hideKeyboard(MainActivity.this);
                        if (storagePermissionGranted) {
                            launchGame();
                        } else {
                            pendingLaunch = true;
                            checkAndRequestStoragePermission();
                            if (storagePermissionGranted) launchGame();
                        }
                    } catch (Exception e) {
                        Log.e("MainActivity", "Error in start button click: " + e.getMessage());
                    }
                }
            });

            importButton.setOnClickListener(v -> {
                hideKeyboard(MainActivity.this);
                if (storagePermissionGranted) {
                    startImportFlow();
                } else {
                    pendingImport = true;
                    checkAndRequestStoragePermission();
                    if (storagePermissionGranted) onStoragePermissionGranted();
                }
            });

            nickInput.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    startButton.performClick();
                    return true;
                }
                return false;
            });
        } catch (Exception e) {
            Log.e("MainActivity", "Error setting up click listeners: " + e.getMessage());
        }
    }

    public static void hideKeyboard(Activity activity) {
        try {
            InputMethodManager inputManager = (InputMethodManager) activity
                    .getSystemService(Context.INPUT_METHOD_SERVICE);

            View currentFocusedView = activity.getCurrentFocus();
            if (currentFocusedView != null) {
                inputManager.hideSoftInputFromWindow(currentFocusedView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "Error hiding keyboard: " + e.getMessage());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            handler.removeCallbacksAndMessages(null);
        } catch (Exception e) {
            Log.e("MainActivity", "Error in onDestroy: " + e.getMessage());
        }
    }
}