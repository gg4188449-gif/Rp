package com.gta.launcher.util;

import android.content.Context;
import android.util.Log;

import com.gta.game.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Готовит папку /storage/emulated/0/GTA/SAMP/, которую ждёт нативный клиент.
 * Недостающие файлы берутся из обычной GTA San Andreas, которую игрок уже импортировал,
 * а шрифт из ресурсов приложения. Уже существующие файлы никогда не перезаписываются:
 * если положить сюда настоящие файлы клиента SA-MP, они будут использованы.
 */
public final class SampFilesPreparer {

    private static final String TAG = "SampFilesPreparer";
    private static final String GTA_DIR = "/storage/emulated/0/GTA/";
    private static final String SAMP_DIR = GTA_DIR + "SAMP/";
    private static final String FONT_NAME = "fonts/arial_bold.ttf";

    /** Первый элемент: имя файла в SAMP/. Остальные: где его искать в GTA/ (по порядку). */
    private static final String[][] SOURCES = {
            {"gta.dat", "data/gta.dat"},
            {"peds.ide", "data/peds.ide"},
            {"vehicles.ide", "data/vehicles.ide"},
            {"handling.cfg", "data/handling.cfg"},
            {"weapon.dat", "data/weapon.dat"},
            {"main.scm", "data/script/mainv1.scm", "data/script/main.scm"},
            {"script.img", "data/script/scriptv1.img", "data/script/script.img"},
    };

    private static final String[] SYSTEM_FONTS = {
            "/system/fonts/Roboto-Bold.ttf",
            "/system/fonts/Roboto-Regular.ttf",
            "/system/fonts/NotoSans-Bold.ttf",
            "/system/fonts/NotoSans-Regular.ttf",
            "/system/fonts/DroidSans-Bold.ttf",
            "/system/fonts/DroidSans.ttf",
    };

    private SampFilesPreparer() {
    }

    /** Список недостающих файлов через запятую или null, если всё на месте. */
    public static String findMissing() {
        StringBuilder sb = new StringBuilder();
        for (String[] entry : SOURCES) {
            if (!isReady(new File(SAMP_DIR + entry[0]))) append(sb, entry[0]);
        }
        if (!isReady(new File(SAMP_DIR + FONT_NAME))) append(sb, FONT_NAME);
        return sb.length() == 0 ? null : sb.toString();
    }

    /**
     * Создаёт недостающие файлы. Возвращает список того, что создать не удалось, или null,
     * если теперь всё на месте.
     */
    public static String ensure(Context context) {
        if (findMissing() == null) return null;

        new File(SAMP_DIR + "fonts").mkdirs();

        for (String[] entry : SOURCES) {
            File target = new File(SAMP_DIR + entry[0]);
            if (isReady(target)) continue;
            for (int i = 1; i < entry.length; i++) {
                File src = findIgnoreCase(new File(GTA_DIR), entry[i]);
                if (src != null && src.isFile() && copy(src, target)) {
                    Log.i(TAG, "Prepared " + entry[0] + " from " + src);
                    break;
                }
            }
        }

        File font = new File(SAMP_DIR + FONT_NAME);
        if (!isReady(font)) prepareFont(context, font);

        return findMissing();
    }

    // ------------------------------------------------------------------ шрифт

    private static void prepareFont(Context context, File target) {
        try (InputStream in = context.getResources().openRawResource(R.font.montserrat_bold)) {
            if (copy(in, target)) {
                Log.i(TAG, "Prepared font from app resources");
                return;
            }
        } catch (Exception e) {
            Log.w(TAG, "Cannot read bundled font: " + e.getMessage());
        }
        for (String path : SYSTEM_FONTS) {
            File src = new File(path);
            if (src.isFile() && copy(src, target)) {
                Log.i(TAG, "Prepared font from " + path);
                return;
            }
        }
    }

    // ---------------------------------------------------------------- помощники

    private static boolean isReady(File f) {
        return f.isFile() && f.length() > 0;
    }

    private static void append(StringBuilder sb, String name) {
        if (sb.length() > 0) sb.append(", ");
        sb.append(name);
    }

    /** Ищет путь вида "data/script/mainv1.scm" без учёта регистра букв в именах. */
    private static File findIgnoreCase(File base, String relPath) {
        File cur = base;
        for (String part : relPath.split("/")) {
            File exact = new File(cur, part);
            if (exact.exists()) {
                cur = exact;
                continue;
            }
            File[] children = cur.listFiles();
            if (children == null) return null;
            File match = null;
            for (File child : children) {
                if (child.getName().equalsIgnoreCase(part)) {
                    match = child;
                    break;
                }
            }
            if (match == null) return null;
            cur = match;
        }
        return cur;
    }

    private static boolean copy(File src, File target) {
        try (InputStream in = new FileInputStream(src)) {
            return copy(in, target);
        } catch (IOException e) {
            Log.e(TAG, "Cannot copy " + src + ": " + e.getMessage());
            return false;
        }
    }

    /** Копирует через временный файл, чтобы не оставить наполовину записанный. */
    private static boolean copy(InputStream in, File target) {
        File dir = target.getParentFile();
        if (dir != null && !dir.exists() && !dir.mkdirs()) return false;
        File tmp = new File(target.getPath() + ".tmp");
        try (OutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        } catch (IOException e) {
            Log.e(TAG, "Cannot write " + target + ": " + e.getMessage());
            tmp.delete();
            return false;
        }
        if (target.exists()) target.delete();
        if (!tmp.renameTo(target)) {
            tmp.delete();
            return false;
        }
        return true;
    }
}
