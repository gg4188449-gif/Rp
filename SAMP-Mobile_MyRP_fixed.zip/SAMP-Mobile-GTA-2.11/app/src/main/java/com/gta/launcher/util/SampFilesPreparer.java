package com.gta.launcher.util;

import android.content.Context;
import android.util.Log;

import com.gta.game.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Готовит папку /storage/emulated/0/GTA/SAMP/, которую ждёт нативный клиент.
 * Недостающие файлы берутся из обычной GTA San Andreas, которую игрок уже импортировал,
 * а шрифт из ресурсов приложения. Уже существующие файлы никогда не перезаписываются:
 * если положить сюда настоящие файлы клиента SA-MP, они будут использованы.
 */
public final class SampFilesPreparer {

    private static final String TAG = "SampFilesPreparer";
    private static final String GTA_DIR = "/storage/emulated/0/GTA/";
    private static final String SAMP_DIR = GTA_DIR + "SAMP/";
    private static final String FONT_NAME = "fonts/arial_bold.ttf";

    /** Первый элемент: имя файла в SAMP/. Остальные: где его искать в GTA/ (по порядку). */
    private static final String[][] SOURCES = {
            {"gta.dat", "data/gta.dat"},
            {"peds.ide", "data/peds.ide"},
            {"vehicles.ide", "data/vehicles.ide"},
            {"handling.cfg", "data/handling.cfg"},
            {"weapon.dat", "data/weapon.dat"},
            {"main.scm", "data/script/mainv1.scm", "data/script/main.scm"},
            {"script.img", "data/script/scriptv1.img", "data/script/script.img"},
    };

    private static final String[] SYSTEM_FONTS = {
            "/system/fonts/Roboto-Bold.ttf",
            "/system/fonts/Roboto-Regular.ttf",
            "/system/fonts/NotoSans-Bold.ttf",
            "/system/fonts/NotoSans-Regular.ttf",
            "/system/fonts/DroidSans-Bold.ttf",
            "/system/fonts/DroidSans.ttf",
    };

    private SampFilesPreparer() {
    }

    /** Список недостающих файлов через запятую или null, если всё на месте. */
    public static String findMissing() {
        StringBuilder sb = new StringBuilder();
        for (String[] entry : SOURCES) {
            if (!isReady(new File(SAMP_DIR + entry[0]))) append(sb, entry[0]);
        }
        if (!isReady(new File(SAMP_DIR + FONT_NAME))) append(sb, FONT_NAME);
        return sb.length() == 0 ? null : sb.toString();
    }

    /**
     * Создаёт недостающие файлы. Возвращает список того, что создать не удалось, или null,
     * если теперь всё на месте.
     */
    public static String ensure(Context context) {
        if (findMissing() == null) return null;

        new File(SAMP_DIR + "fonts").mkdirs();

        for (String[] entry : SOURCES) {
            File target = new File(SAMP_DIR + entry[0]);
            if (isReady(target)) continue;
            for (int i = 1; i < entry.length; i++) {
                File src = findIgnoreCase(new File(GTA_DIR), entry[i]);
                if (src != null && src.isFile() && copy(src, target)) {
                    Log.i(TAG, "Prepared " + entry[0] + " from " + src);
                    break;
                }
            }
        }

        if (!isReady(new File(SAMP_DIR + "main.scm")) || !isReady(new File(SAMP_DIR + "script.img"))) {
            prepareScripts();
        }

        File font = new File(SAMP_DIR + FONT_NAME);
        if (!isReady(font)) prepareFont(context, font);

        return findMissing();
    }

    // ------------------------------------------------------------ main.scm и script.img

    private static final String[] MAIN_NAMES = {"mainv1.scm", "main.scm"};
    private static final String[] IMG_NAMES = {"scriptv1.img", "script.img"};

    /**
     * main.scm и script.img нет в обычных папках data/script. Ищем их по всей папке GTA/,
     * в папке официальной игры и внутри .obb (это ZIP-архив).
     */
    private static void prepareScripts() {
        File mainTarget = new File(SAMP_DIR + "main.scm");
        File imgTarget = new File(SAMP_DIR + "script.img");

        String[] roots = {GTA_DIR, "/storage/emulated/0/Android/data/com.rockstargames.gtasa/files"};
        for (String root : roots) {
            if (!isReady(mainTarget)) copyFound(new File(root), MAIN_NAMES, mainTarget);
            if (!isReady(imgTarget)) copyFound(new File(root), IMG_NAMES, imgTarget);
        }
        if (isReady(mainTarget) && isReady(imgTarget)) return;

        for (File obb : GameDataImporter.findAutoObbs()) {
            extractScriptsFromObb(obb, mainTarget, imgTarget);
        }
    }

    private static void copyFound(File root, String[] names, File target) {
        File found = searchByName(root, names, 0);
        if (found != null && copy(found, target)) {
            Log.i(TAG, "Prepared " + target.getName() + " from " + found);
        }
    }

    private static File searchByName(File dir, String[] names, int depth) {
        File[] list = dir.listFiles();
        if (list == null) return null;
        for (File f : list) {
            if (!f.isFile() || f.length() == 0) continue;
            for (String name : names) {
                if (f.getName().equalsIgnoreCase(name)) return f;
            }
        }
        if (depth >= 5) return null;
        for (File f : list) {
            // свою папку SAMP не просматриваем, там цели, а не источники
            if (f.isDirectory() && !(depth == 0 && f.getName().equalsIgnoreCase("SAMP"))) {
                File found = searchByName(f, names, depth + 1);
                if (found != null) return found;
            }
        }
        return null;
    }

    private static void extractScriptsFromObb(File obb, File mainTarget, File imgTarget) {
        try (ZipFile zf = new ZipFile(obb)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String path = e.getName().replace('\\', '/');
                String base = path.substring(path.lastIndexOf('/') + 1).toLowerCase(Locale.ROOT);
                File target = null;
                if (base.equals("mainv1.scm") || base.equals("main.scm")) {
                    target = mainTarget;
                } else if (base.equals("scriptv1.img") || base.equals("script.img")) {
                    target = imgTarget;
                }
                if (target == null) continue;
                try (InputStream in = zf.getInputStream(e)) {
                    if (copy(in, target)) {
                        Log.i(TAG, "Prepared " + target.getName() + " from " + obb.getName() + ":" + path);
                    }
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Cannot read " + obb.getName() + ": " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ шрифт

    private static void prepareFont(Context context, File target) {
        try (InputStream in = context.getResources().openRawResource(R.font.montserrat_bold)) {
            if (copy(in, target)) {
                Log.i(TAG, "Prepared font from app resources");
                return;
            }
        } catch (Exception e) {
            Log.w(TAG, "Cannot read bundled font: " + e.getMessage());
        }
        for (String path : SYSTEM_FONTS) {
            File src = new File(path);
            if (src.isFile() && copy(src, target)) {
                Log.i(TAG, "Prepared font from " + path);
                return;
            }
        }
    }

    // ---------------------------------------------------------------- помощники

    private static boolean isReady(File f) {
        return f.isFile() && f.length() > 0;
    }

    private static void append(StringBuilder sb, String name) {
        if (sb.length() > 0) sb.append(", ");
        sb.append(name);
    }

    /** Ищет путь вида "data/script/mainv1.scm" без учёта регистра букв в именах. */
    private static File findIgnoreCase(File base, String relPath) {
        File cur = base;
        for (String part : relPath.split("/")) {
            File exact = new File(cur, part);
            if (exact.exists()) {
                cur = exact;
                continue;
            }
            File[] children = cur.listFiles();
            if (children == null) return null;
            File match = null;
            for (File child : children) {
                if (child.getName().equalsIgnoreCase(part)) {
                    match = child;
                    break;
                }
            }
            if (match == null) return null;
            cur = match;
        }
        return cur;
    }

    private static boolean copy(File src, File target) {
        try (InputStream in = new FileInputStream(src)) {
            return copy(in, target);
        } catch (IOException e) {
            Log.e(TAG, "Cannot copy " + src + ": " + e.getMessage());
            return false;
        }
    }

    /** Копирует через временный файл, чтобы не оставить наполовину записанный. */
    private static boolean copy(InputStream in, File target) {
        File dir = target.getParentFile();
        if (dir != null && !dir.exists() && !dir.mkdirs()) return false;
        File tmp = new File(target.getPath() + ".tmp");
        try (OutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        } catch (IOException e) {
            Log.e(TAG, "Cannot write " + target + ": " + e.getMessage());
            tmp.delete();
            return false;
        }
        if (target.exists()) target.delete();
        if (!tmp.renameTo(target)) {
            tmp.delete();
            return false;
        }
        return true;
    }
}
