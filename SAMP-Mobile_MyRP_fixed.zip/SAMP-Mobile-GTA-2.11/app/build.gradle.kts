plugins {
    id("com.android.application")
}

android {
    compileSdk = 36

    namespace = "com.gta.game"

    defaultConfig {
        applicationId = "com.gta.game"
        minSdk = 28
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"

        multiDexEnabled = true

        ndk {
            abiFilters.add("arm64-v8a")
        }

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    androidResources {
        localeFilters += listOf("ru", "en")
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
            pickFirsts.add("**/libbass.so")
            pickFirsts.add("**/libbass_ssl.so")
            pickFirsts.add("**/libc++_shared.so")
            excludes.add("META-INF/*")
        }
        resources {
            excludes.add("META-INF/*")
        }
    }

    ndkVersion = "26.2.11394342"

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
        }
    }

    applicationVariants.all {
        outputs.all {
            val apkName = "GTA-2.11-${buildType.name}.apk"
            (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl).outputFileName = apkName
        }
    }

    buildTypes {
        debug {
            isDebuggable = true
            isJniDebuggable = true
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        release {

            isDebuggable = false
            isJniDebuggable = false
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    buildFeatures {
        prefab = true
    }
}

dependencies {
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar"))))
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("com.google.android.play:asset-delivery:2.3.0")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    implementation("com.intuit.sdp:sdp-android:1.1.0")
    implementation("androidx.lifecycle:lifecycle-process:2.6.2")
    implementation("com.joom.paranoid:paranoid-gradle-plugin:0.3.14")
    implementation("com.bytedance.android:shadowhook:1.0.10")
    implementation("androidx.multidex:multidex:2.0.1")
}