package com.rockstargames.oswrapper.services;

import com.rockstargames.oswrapper.GameActivityBase;
import kotlin.jvm.internal.Intrinsics;

public class LanguageServices implements ILanguageServices {
    private static String TAG = "LanguageServices";
    private GameActivityBase activity;

    public LanguageServices(GameActivityBase activity) {
        Intrinsics.checkNotNullParameter(activity, "activity");
        this.activity = activity;
    }

    /* JADX WARN: Removed duplicated region for block: B:56:0x0092  */
    @Override // com.rockstargames.oswrapper.services.ILanguageServices
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public int getDeviceLocale() {
        // Всегда английский (american.gxt). По языку телефона игра могла запросить файл текста,
        // которого нет в данных (например japanese.gxt), и падала при его чтении.
        // Для мультиплеера язык встроенных текстов GTA не важен: весь текст идёт с сервера.
        return 0;
    }
}
