package com.gta.launcher.util;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Ловит вылеты игры и показывает причину при следующем запуске лаунчера.
 * Java-исключения (например, не загрузилась библиотека) сохраняются сами, а для падений
 * нативного кода (SIGSEGV и т.п.) читается причина завершения процесса из системы (Android 11+).
 */
public final class CrashReporter {

    private static final String TAG = "CrashReporter";
    private static final String FILE_NAME = "crash_report.txt";
    private static final String PREFS = "launcher";
    private static final String PREF_LAST_EXIT = "last_exit_ts";
    private static final String EXTERNAL_COPY = "/storage/emulated/0/GTA/crash_report.txt";

    private CrashReporter() {
    }

    /** Ставит перехватчик Java-вылетов. Вызывать как можно раньше. */
    public static void install(Context context) {
        final Context app = context.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                StringWriter sw = new StringWriter();
                throwable.printStackTrace(new PrintWriter(sw));
                String text = "Java-вылет в потоке " + thread.getName() + "\n" + sw;
                Files.write(new File(app.getFilesDir(), FILE_NAME).toPath(),
                        text.getBytes(StandardCharsets.UTF_8));
            } catch (Throwable ignored) {
                // отчёт не получилось записать, это не должно ломать обычную обработку вылета
            }
            if (previous != null) previous.uncaughtException(thread, throwable);
        });
    }

    /**
     * Возвращает текст отчёта о последнем вылете или null, если вылетов не было.
     * Повторно один и тот же вылет не показывается.
     */
    public static String collect(Context context) {
        StringBuilder sb = new StringBuilder();

        File javaReport = new File(context.getFilesDir(), FILE_NAME);
        if (javaReport.exists()) {
            try {
                sb.append(new String(Files.readAllBytes(javaReport.toPath()), StandardCharsets.UTF_8)).append('\n');
            } catch (IOException e) {
                Log.e(TAG, "Cannot read report: " + e.getMessage(), e);
            }
            //noinspection ResultOfMethodCallIgnored
            javaReport.delete();
        }

        String exit = lastBadExit(context);
        if (exit != null) sb.append(exit).append('\n');

        if (sb.length() == 0) return null;
        sb.append(deviceInfo(context));
        String text = sb.toString();
        saveExternalCopy(text);
        return text;
    }

    private static String lastBadExit(Context context) {
        if (Build.VERSION.SDK_INT < 30) return null;
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return null;
            List<ApplicationExitInfo> list = am.getHistoricalProcessExitReasons(context.getPackageName(), 0, 5);
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            long lastShown = prefs.getLong(PREF_LAST_EXIT, 0);
            for (ApplicationExitInfo info : list) {
                if (info.getTimestamp() <= lastShown) continue;
                int reason = info.getReason();
                if (!isBadReason(reason)) continue;
                prefs.edit().putLong(PREF_LAST_EXIT, info.getTimestamp()).apply();
                String when = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                        .format(new Date(info.getTimestamp()));
                StringBuilder sb = new StringBuilder();
                sb.append("Причина завершения: ").append(reasonName(reason)).append('\n');
                sb.append("Время: ").append(when).append('\n');
                if (reason == ApplicationExitInfo.REASON_CRASH_NATIVE
                        || reason == ApplicationExitInfo.REASON_SIGNALED) {
                    sb.append("Сигнал: ").append(info.getStatus()).append(" (11 = ошибка доступа к памяти)\n");
                } else {
                    sb.append("Код: ").append(info.getStatus()).append('\n');
                }
                if (info.getDescription() != null) {
                    sb.append("Описание: ").append(info.getDescription()).append('\n');
                }
                return sb.toString();
            }
        } catch (Throwable t) {
            Log.e(TAG, "Cannot read exit info: " + t.getMessage(), t);
        }
        return null;
    }

    private static boolean isBadReason(int reason) {
        return reason == ApplicationExitInfo.REASON_SIGNALED
                || reason == ApplicationExitInfo.REASON_LOW_MEMORY
                || reason == ApplicationExitInfo.REASON_CRASH
                || reason == ApplicationExitInfo.REASON_CRASH_NATIVE
                || reason == ApplicationExitInfo.REASON_ANR
                || reason == ApplicationExitInfo.REASON_INITIALIZATION_FAILURE
                || reason == ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE;
    }

    private static String reasonName(int reason) {
        if (reason == ApplicationExitInfo.REASON_CRASH_NATIVE) return "падение нативного кода (CRASH_NATIVE)";
        if (reason == ApplicationExitInfo.REASON_CRASH) return "Java-вылет (CRASH)";
        if (reason == ApplicationExitInfo.REASON_SIGNALED) return "убит сигналом (SIGNALED)";
        if (reason == ApplicationExitInfo.REASON_LOW_MEMORY) return "не хватило памяти (LOW_MEMORY)";
        if (reason == ApplicationExitInfo.REASON_ANR) return "приложение зависло (ANR)";
        if (reason == ApplicationExitInfo.REASON_INITIALIZATION_FAILURE) return "ошибка запуска (INITIALIZATION_FAILURE)";
        if (reason == ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE) return "превышение ресурсов";
        return String.valueOf(reason);
    }

    /** Данные об устройстве: по ним видно, подходит ли телефон клиенту. */
    public static String deviceInfo(Context context) {
        StringBuilder sb = new StringBuilder("\n--- Устройство ---\n");
        sb.append("Модель: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        sb.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("Архитектуры: ").append(Arrays.toString(Build.SUPPORTED_ABIS)).append('\n');
        sb.append("64-бит процесс: ").append(android.os.Process.is64Bit()).append('\n');
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            if (am != null) {
                am.getMemoryInfo(mi);
                sb.append("Память: ").append(mi.totalMem / (1024 * 1024)).append(" МБ всего, ")
                        .append(mi.availMem / (1024 * 1024)).append(" МБ свободно\n");
            }
        } catch (Throwable ignored) {
            // не критично
        }
        try {
            sb.append("Размер страницы памяти: ").append(Os.sysconf(OsConstants._SC_PAGESIZE)).append('\n');
        } catch (Throwable ignored) {
            // не критично
        }
        try {
            String dir = context.getApplicationInfo().nativeLibraryDir;
            String[] libs = new File(dir).list();
            sb.append("Нативные библиотеки: ").append(libs == null ? "папка недоступна" : Arrays.toString(libs)).append('\n');
        } catch (Throwable ignored) {
            // не критично
        }
        return sb.toString();
    }

    private static void saveExternalCopy(String text) {
        try {
            File file = new File(EXTERNAL_COPY);
            File parent = file.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) return;
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write(text.getBytes(StandardCharsets.UTF_8));
            }
        } catch (Throwable ignored) {
            // копия в общей папке нужна только для удобства
        }
    }
}
